create function guardar_progreso(id_usuario integer, id_contenido integer, progreso integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO PROGRESO (id_usuario, id_contenido, progreso)
    VALUES (id_usuario, id_contenido, progreso)
    ON CONFLICT (id_usuario, id_contenido)
    DO UPDATE SET progreso = EXCLUDED.progreso;
END;
$$;

alter function guardar_progreso(integer, integer, integer) owner to healthtone;

