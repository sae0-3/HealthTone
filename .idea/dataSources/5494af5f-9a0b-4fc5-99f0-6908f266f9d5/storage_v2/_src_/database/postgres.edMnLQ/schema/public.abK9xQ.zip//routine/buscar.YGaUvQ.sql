create function buscar(pattern text)
    returns TABLE(id integer, nombre character varying, autor character varying, url_texto text, url_portada text, url_audio text, categorias json)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        co.id,
        co.nombre,
        co.autor,
        co.url_texto,
        co.url_portada,
        co.url_audio,
        COALESCE(
            json_agg(
            json_build_object(
                'id', ca.id,
                'name', ca.nombre
            )
            ) FILTER (WHERE ca.id IS NOT NULL),
            '[]'
        ) AS categorias
    FROM CONTENIDO co
        LEFT JOIN R_CONTENIDO_CATEGORIA r ON id_contenido = co.id
        LEFT JOIN CATEGORIA ca ON ca.id = id_categoria
    WHERE co.nombre ~* pattern OR co.autor ~* pattern
    GROUP BY co.id, co.nombre, co.autor, co.url_texto, co.url_portada, co.url_audio;
END;
$$;

alter function buscar(text) owner to healthtone;

